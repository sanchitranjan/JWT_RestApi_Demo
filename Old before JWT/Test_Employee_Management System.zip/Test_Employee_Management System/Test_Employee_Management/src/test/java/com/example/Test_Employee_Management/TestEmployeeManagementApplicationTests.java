package com.example.Test_Employee_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestEmployeeManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
